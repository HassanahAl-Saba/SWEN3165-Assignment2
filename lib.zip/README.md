1. Download NODE JS
2. Run npm install from the command line / terminal
3. npm test will run the tests